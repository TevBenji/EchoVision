import React, { useState, useEffect } from 'react';
import Layout from '@/components/layout/Layout';
import CameraView from '@/components/vision/CameraView';
import ObjectDetection, { DetectedObject } from '@/components/vision/ObjectDetection';
import NavigationInstructions from '@/components/vision/NavigationInstructions';
import VoiceListener from '@/components/vision/VoiceListener';
import { Button } from '@/components/ui/button';
import { Users, MessageCircle, User, Zap, RotateCcw, X, Info } from 'lucide-react';
import { Link } from 'react-router-dom';

const Camera = () => {
  const [detections, setDetections] = useState<DetectedObject[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [showInstructions, setShowInstructions] = useState(false);
  const [isInstructionsExpanded, setIsInstructionsExpanded] = useState(false);
  const [showWelcome, setShowWelcome] = useState(true);
  
  useEffect(() => {
    const mockObjects = [
      {
        id: 1,
        label: 'Chair',
        confidence: 0.92,
        bbox: { x: 0.2, y: 0.4, width: 0.15, height: 0.25 },
        distance: 2.3
      },
      {
        id: 2,
        label: 'Table',
        confidence: 0.87,
        bbox: { x: 0.6, y: 0.5, width: 0.25, height: 0.2 },
        distance: 3.1
      },
      {
        id: 3,
        label: 'Person',
        confidence: 0.96,
        bbox: { x: 0.75, y: 0.3, width: 0.15, height: 0.4 },
        distance: 4.2
      }
    ];
    
    const timer = setTimeout(() => {
      setDetections(mockObjects);
      setIsListening(true);
    }, 3000);
    
    return () => clearTimeout(timer);
  }, []);

  const handleVoiceCommand = (command: string) => {
    console.log('Voice command received:', command);
  };

  const handleCloseWelcome = () => {
    setShowWelcome(false);
  };

  const handleShutter = () => {
    console.log('Camera shutter pressed');
  };

  return (
    <Layout hideFooter>
      <div className="relative h-full bg-black">
        <div className="relative h-[100vh] flex flex-col">
          <div className="absolute top-0 left-0 right-0 z-10 px-4 py-3 flex justify-between items-center">
            <Button variant="ghost" size="icon" className="rounded-full bg-black/50 text-white">
              <User className="h-5 w-5" />
            </Button>
            
            <div className="rounded-full bg-black/70 px-4 py-1.5 flex items-center gap-1">
              <Users className="h-4 w-4 text-white" />
              <span className="text-sm text-white font-medium">5 Friends</span>
            </div>
            
            <Button variant="ghost" size="icon" className="rounded-full bg-black/50 text-white">
              <MessageCircle className="h-5 w-5" />
            </Button>
          </div>
          
          <CameraView 
            onFrame={(imageData) => {
              console.log('Frame received, size:', imageData.width, 'x', imageData.height);
            }}
            className="flex-1 rounded-3xl overflow-hidden"
          />
          
          <ObjectDetection 
            detections={detections} 
            className="absolute inset-0 pointer-events-none"
          />
          
          <div className="absolute bottom-8 left-0 right-0 flex justify-center items-center px-6">
            <div className="w-full flex justify-between items-center">
              <Button variant="ghost" size="icon" className="text-white opacity-80 hover:opacity-100">
                <Zap className="h-6 w-6" />
              </Button>
              
              <Button 
                className="h-16 w-16 rounded-full bg-white border-4 border-yellow-400 flex items-center justify-center p-0 shadow-xl hover:bg-gray-100 transition-all"
                onClick={handleShutter}
              >
                <div className="h-14 w-14 rounded-full bg-white"></div>
              </Button>
              
              <Button variant="ghost" size="icon" className="text-white opacity-80 hover:opacity-100">
                <RotateCcw className="h-6 w-6" />
              </Button>
            </div>
          </div>
        </div>
        
        {showInstructions && (
          <div className="absolute bottom-28 left-4 right-4 z-20">
            <NavigationInstructions 
              isExpanded={isInstructionsExpanded}
              onToggleExpand={() => setIsInstructionsExpanded(!isInstructionsExpanded)}
            />
          </div>
        )}
        
        <div className="hidden">
          <VoiceListener 
            isListening={isListening} 
            onVoiceCommand={handleVoiceCommand} 
          />
        </div>
        
        {showWelcome && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
            <div className="glass-card rounded-xl p-6 max-w-md relative animate-fade-in">
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute top-2 right-2"
                onClick={handleCloseWelcome}
              >
                <X className="h-4 w-4" />
              </Button>
              
              <div className="text-center mb-6">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                  <Info className="h-6 w-6 text-primary" />
                </div>
                <h2 className="text-xl font-bold mb-2">Welcome to EchoVision</h2>
                <p className="text-muted-foreground">
                  Your AI assistant is now ready to guide you through indoor spaces
                </p>
              </div>
              
              <div className="space-y-4 mb-6">
                <div className="flex items-start">
                  <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center mr-3 flex-shrink-0">
                    <span className="font-medium">1</span>
                  </div>
                  <p className="text-sm">The app will continuously scan your surroundings for objects and people</p>
                </div>
                
                <div className="flex items-start">
                  <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center mr-3 flex-shrink-0">
                    <span className="font-medium">2</span>
                  </div>
                  <p className="text-sm">Voice instructions will guide you based on what's detected</p>
                </div>
                
                <div className="flex items-start">
                  <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center mr-3 flex-shrink-0">
                    <span className="font-medium">3</span>
                  </div>
                  <p className="text-sm">Ask questions or give commands using your voice at any time</p>
                </div>
              </div>
              
              <Button 
                className="w-full" 
                onClick={handleCloseWelcome}
              >
                Get Started
              </Button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Camera;
