
import React from 'react';
import { Link } from 'react-router-dom';
import { Settings, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Header: React.FC = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 px-6 py-4">
      <div className="glass-card rounded-full px-4 py-2 mx-auto max-w-screen-sm flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <div className="relative w-8 h-8 flex items-center justify-center bg-primary rounded-full">
            <div className="absolute w-4 h-4 bg-white rounded-full animate-pulse-subtle"></div>
            <div className="absolute w-6 h-6 border-2 border-white rounded-full animate-radar"></div>
          </div>
          <span className="text-lg font-medium">EchoVision</span>
        </Link>
        
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon" className="btn-icon" aria-label="Help">
            <HelpCircle className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="btn-icon" aria-label="Settings">
            <Settings className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
