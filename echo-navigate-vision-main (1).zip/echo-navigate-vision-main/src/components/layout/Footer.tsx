
import React from 'react';
import { Link } from 'react-router-dom';
import { Mic, Camera, User } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="fixed bottom-0 left-0 right-0 z-50 p-4">
      <div className="glass-card rounded-full px-6 py-4 mx-auto max-w-screen-sm flex items-center justify-around">
        <Link to="/profile" className="flex flex-col items-center">
          <div className="p-2 rounded-full bg-secondary/80 text-primary">
            <User className="h-6 w-6" />
          </div>
          <span className="text-xs mt-1">Profile</span>
        </Link>
        
        <Link to="/camera" className="flex flex-col items-center">
          <div className="p-4 rounded-full bg-primary text-white shadow-lg">
            <Camera className="h-6 w-6" />
          </div>
          <span className="text-xs mt-1">Camera</span>
        </Link>
        
        <Link to="/voice" className="flex flex-col items-center">
          <div className="p-2 rounded-full bg-secondary/80 text-primary">
            <Mic className="h-6 w-6" />
          </div>
          <span className="text-xs mt-1">Voice</span>
        </Link>
      </div>
    </footer>
  );
};

export default Footer;
