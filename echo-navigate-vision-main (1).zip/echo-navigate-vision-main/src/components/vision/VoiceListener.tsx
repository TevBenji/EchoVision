
import React, { useState, useEffect } from 'react';
import { Mic, MicOff } from 'lucide-react';
import { cn } from '@/lib/utils';

interface VoiceListenerProps {
  isListening?: boolean;
  onVoiceCommand?: (command: string) => void;
  className?: string;
}

const VoiceListener: React.FC<VoiceListenerProps> = ({
  isListening = false,
  onVoiceCommand,
  className
}) => {
  const [mockTranscript, setMockTranscript] = useState<string>('');
  
  // For a real implementation, we'd use Web Speech API
  // For now, we'll just simulate voice commands

  useEffect(() => {
    if (isListening) {
      // Simulate speech recognition
      const commands = [
        'Can you describe what\'s in front of me?',
        'Are there any obstacles nearby?',
        'How far is the nearest chair?',
        'Find the exit',
        'Where is the conference table?'
      ];
      
      // This is just a demo for UI visualization
      let timeoutId: NodeJS.Timeout;
      
      const simulateCommand = () => {
        // Clear any existing timeouts
        if (timeoutId) clearTimeout(timeoutId);
        
        // Reset transcript
        setMockTranscript('');
        
        // Pick a random command
        const randomCommand = commands[Math.floor(Math.random() * commands.length)];
        
        // Simulate typing effect
        let i = 0;
        const typeEffect = () => {
          if (i < randomCommand.length) {
            setMockTranscript(randomCommand.substring(0, i + 1));
            i++;
            timeoutId = setTimeout(typeEffect, 50);
          } else {
            // When finished "typing", trigger the command
            if (onVoiceCommand) {
              timeoutId = setTimeout(() => {
                onVoiceCommand(randomCommand);
                // Reset transcript after a delay
                timeoutId = setTimeout(() => {
                  setMockTranscript('');
                  // Start over with a new command after a pause
                  timeoutId = setTimeout(simulateCommand, 3000);
                }, 1000);
              }, 500);
            }
          }
        };
        
        // Start typing effect
        timeoutId = setTimeout(typeEffect, 1000);
      };
      
      // Start simulation
      timeoutId = setTimeout(simulateCommand, 1000);
      
      // Cleanup
      return () => {
        if (timeoutId) clearTimeout(timeoutId);
      };
    } else {
      // Reset when not listening
      setMockTranscript('');
    }
  }, [isListening, onVoiceCommand]);

  return (
    <div className={cn("voice-listener glass-card rounded-full p-4", className)}>
      <div className="relative flex flex-col items-center">
        <div className={cn(
          "w-14 h-14 rounded-full flex items-center justify-center transition-colors duration-300",
          isListening ? "bg-primary" : "bg-muted"
        )}>
          {isListening ? (
            <Mic className="h-6 w-6 text-white" />
          ) : (
            <MicOff className="h-6 w-6 text-foreground/60" />
          )}
        </div>
        
        {isListening && (
          <div className="mt-4 voice-pulse">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
          </div>
        )}
        
        {mockTranscript && (
          <div className="mt-4 glass-card px-4 py-2 rounded-full max-w-xs animate-fade-in">
            <p className="text-sm text-center">{mockTranscript}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default VoiceListener;
