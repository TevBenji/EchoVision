
import React, { useRef, useState, useEffect } from 'react';
import { AlertTriangle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface CameraViewProps {
  onFrame?: (imageData: ImageData) => void;
  className?: string;
}

const CameraView: React.FC<CameraViewProps> = ({ 
  onFrame,
  className
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    let stream: MediaStream | null = null;
    let animationFrameId: number;
    
    const startCamera = async () => {
      setIsLoading(true);
      setError(null);
      try {
        // Request camera access
        stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            facingMode: 'environment',
            width: { ideal: 1280 },
            height: { ideal: 720 }
          } 
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
          setIsActive(true);
          setIsLoading(false);
          
          // Process frames if onFrame is provided
          if (onFrame && canvasRef.current) {
            const ctx = canvasRef.current.getContext('2d');
            const processFrame = () => {
              if (videoRef.current && ctx && canvasRef.current) {
                // Match canvas size to video
                canvasRef.current.width = videoRef.current.videoWidth;
                canvasRef.current.height = videoRef.current.videoHeight;
                
                // Draw current video frame to canvas
                ctx.drawImage(
                  videoRef.current, 
                  0, 0, 
                  videoRef.current.videoWidth, 
                  videoRef.current.videoHeight
                );
                
                // Get image data and pass to callback
                const imageData = ctx.getImageData(
                  0, 0, 
                  videoRef.current.videoWidth, 
                  videoRef.current.videoHeight
                );
                onFrame(imageData);
              }
              
              // Continue processing frames
              animationFrameId = requestAnimationFrame(processFrame);
            };
            
            processFrame();
          }
        }
      } catch (err) {
        console.error('Error accessing camera:', err);
        setError('Camera access denied or not available.');
        setIsLoading(false);
      }
    };
    
    startCamera();
    
    // Cleanup function
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
      setIsActive(false);
    };
  }, [onFrame]);

  const retryCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsActive(false);
    
    // Slight delay before retrying
    setTimeout(() => {
      if (videoRef.current) {
        navigator.mediaDevices.getUserMedia({ 
          video: { 
            facingMode: 'environment',
            width: { ideal: 1280 },
            height: { ideal: 720 }
          } 
        })
        .then(stream => {
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play()
              .then(() => {
                setIsActive(true);
                setError(null);
                setIsLoading(false);
              })
              .catch(err => {
                console.error('Error playing video:', err);
                setError('Failed to start camera video.');
                setIsLoading(false);
              });
          }
        })
        .catch(err => {
          console.error('Error accessing camera on retry:', err);
          setError('Camera access denied or not available.');
          setIsLoading(false);
        });
      }
    }, 500);
  };

  return (
    <div className={cn('camera-viewport relative bg-black w-full h-full', className)}>
      <video 
        ref={videoRef}
        className={cn(
          'absolute inset-0 w-full h-full object-cover transition-opacity duration-300',
          isActive ? 'opacity-100' : 'opacity-0'
        )}
        playsInline
        muted
      />
      
      <canvas 
        ref={canvasRef}
        className="hidden" // Hidden canvas for processing
      />
      
      {/* Loading overlay */}
      {isLoading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 z-10">
          <Loader2 className="h-10 w-10 text-white animate-spin mb-4" />
          <p className="text-white text-lg font-medium">Accessing camera...</p>
        </div>
      )}
      
      {/* Error overlay */}
      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 z-10 p-6">
          <AlertTriangle className="h-12 w-12 text-destructive mb-4" />
          <h3 className="text-white text-xl font-medium mb-2">Camera Error</h3>
          <p className="text-white/80 text-center mb-6">{error}</p>
          <Button onClick={retryCamera} className="bg-white text-black hover:bg-gray-200">
            Retry Camera Access
          </Button>
        </div>
      )}
    </div>
  );
};

export default CameraView;
