
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, Mic, Settings, User } from 'lucide-react';
import Layout from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';

const Index = () => {
  const navigate = useNavigate();

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center h-[80vh]">
        <div className="text-center mb-10 animate-fade-in">
          <div className="relative w-20 h-20 mx-auto mb-6">
            <div className="absolute inset-0 rounded-full bg-primary/20 animate-pulse"></div>
            <div className="absolute inset-2 rounded-full bg-primary/30 animate-pulse animation-delay-200"></div>
            <div className="absolute inset-4 rounded-full bg-primary flex items-center justify-center">
              <div className="text-white text-xl font-semibold">EV</div>
            </div>
          </div>
          <h1 className="text-4xl font-bold mb-2">EchoVision</h1>
          <p className="text-muted-foreground max-w-md">
            AI-driven vision assistant that helps navigate indoor spaces with confidence
          </p>
        </div>
        
        <div className="grid grid-cols-2 gap-4 w-full max-w-md animate-slide-in-up">
          <Button 
            className="flex items-center justify-center flex-col h-32 glass-card hover:bg-primary/5"
            variant="outline"
            onClick={() => navigate('/camera')}
          >
            <Camera className="h-8 w-8 mb-2 text-primary" />
            <span className="text-lg font-medium">Start Camera</span>
          </Button>
          
          <Button 
            className="flex items-center justify-center flex-col h-32 glass-card hover:bg-primary/5"
            variant="outline"
            onClick={() => navigate('/voice')}
          >
            <Mic className="h-8 w-8 mb-2 text-primary" />
            <span className="text-lg font-medium">Voice Control</span>
          </Button>
          
          <Button 
            className="flex items-center justify-center flex-col h-32 glass-card hover:bg-primary/5"
            variant="outline"
            onClick={() => navigate('/profile')}
          >
            <User className="h-8 w-8 mb-2 text-primary" />
            <span className="text-lg font-medium">User Profile</span>
          </Button>
          
          <Button 
            className="flex items-center justify-center flex-col h-32 glass-card hover:bg-primary/5"
            variant="outline"
            onClick={() => navigate('/settings')}
          >
            <Settings className="h-8 w-8 mb-2 text-primary" />
            <span className="text-lg font-medium">Settings</span>
          </Button>
        </div>
      </div>
    </Layout>
  );
};

export default Index;
