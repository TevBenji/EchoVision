import React, { useState, useEffect } from 'react';
import { Volume2, ChevronUp, ChevronDown, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface NavigationInstruction {
  id: number;
  text: string;
  priority: 'high' | 'medium' | 'low';
  timestamp: Date;
}

interface NavigationInstructionsProps {
  instructions?: NavigationInstruction[];
  isExpanded?: boolean;
  onToggleExpand?: () => void;
  className?: string;
}

const NavigationInstructions: React.FC<NavigationInstructionsProps> = ({
  instructions = [],
  isExpanded = false,
  onToggleExpand,
  className
}) => {
  const [mockInstructions, setMockInstructions] = useState<NavigationInstruction[]>([
    {
      id: 1,
      text: "There's a chair about 2 meters ahead on your right. Consider moving slightly left to avoid it.",
      priority: 'medium',
      timestamp: new Date()
    },
    {
      id: 2,
      text: 'Conference table detected 3 meters ahead. There appears to be an open seat at the far end.',
      priority: 'low',
      timestamp: new Date(Date.now() - 30000)
    },
    {
      id: 3,
      text: 'Caution: A person is walking towards you from the left, about 1.5 meters away.',
      priority: 'high',
      timestamp: new Date(Date.now() - 60000)
    }
  ]);

  const allInstructions = instructions.length > 0 ? instructions : mockInstructions;
  
  const sortedInstructions = [...allInstructions].sort((a, b) => {
    const priorityOrder = { high: 0, medium: 1, low: 2 };
    if (a.priority !== b.priority) {
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    }
    return b.timestamp.getTime() - a.timestamp.getTime();
  });

  const highPriorityInstruction = sortedInstructions.find(instr => instr.priority === 'high');
  
  const primaryInstruction = highPriorityInstruction || sortedInstructions[0];
  
  return (
    <div className={cn("glass-card rounded-xl overflow-hidden transition-all duration-300", 
      isExpanded ? "max-h-96" : "max-h-24",
      className
    )}>
      <div className="flex items-start p-4 border-b border-border/40">
        <div className="flex-shrink-0 mr-3 mt-1">
          <Volume2 className="h-5 w-5 text-primary" />
        </div>
        
        <div className="flex-1">
          {primaryInstruction ? (
            <div className="flex items-start">
              {primaryInstruction.priority === 'high' && (
                <div className="flex-shrink-0 mr-2">
                  <AlertCircle className="h-5 w-5 text-destructive animate-pulse" />
                </div>
              )}
              <p className={cn(
                "text-sm",
                primaryInstruction.priority === 'high' && "font-medium"
              )}>
                {primaryInstruction.text}
              </p>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No navigation instructions yet.</p>
          )}
        </div>
        
        <Button 
          variant="ghost" 
          size="sm" 
          className="ml-2 flex-shrink-0 p-0 h-6 w-6"
          onClick={onToggleExpand}
        >
          {isExpanded ? (
            <ChevronUp className="h-4 w-4" />
          ) : (
            <ChevronDown className="h-4 w-4" />
          )}
        </Button>
      </div>
      
      {isExpanded && sortedInstructions.length > 1 && (
        <div className="p-4 max-h-80 overflow-y-auto">
          <h3 className="text-xs uppercase text-muted-foreground font-medium mb-3">Previous Instructions</h3>
          <div className="space-y-4">
            {sortedInstructions.slice(1).map(instruction => (
              <div key={instruction.id} className="flex items-start">
                {instruction.priority === 'high' && (
                  <div className="flex-shrink-0 mr-2">
                    <AlertCircle className="h-4 w-4 text-destructive/70" />
                  </div>
                )}
                <div>
                  <p className="text-sm">{instruction.text}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {formatTimestamp(instruction.timestamp)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const formatTimestamp = (date: Date): string => {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSec = Math.floor(diffMs / 1000);
  
  if (diffSec < 60) return `${diffSec} seconds ago`;
  if (diffSec < 3600) return `${Math.floor(diffSec / 60)} minutes ago`;
  if (diffSec < 86400) return `${Math.floor(diffSec / 3600)} hours ago`;
  
  return date.toLocaleString();
};

export default NavigationInstructions;
