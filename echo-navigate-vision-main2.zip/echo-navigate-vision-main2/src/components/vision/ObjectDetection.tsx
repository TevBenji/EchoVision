
import React, { useState, useRef, useEffect } from 'react';
import { Info } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface DetectedObject {
  id: number;
  label: string;
  confidence: number;
  bbox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  distance?: number; // Estimated distance in meters
}

interface ObjectDetectionProps {
  detections: DetectedObject[];
  className?: string;
  showLabels?: boolean;
}

const ObjectDetection: React.FC<ObjectDetectionProps> = ({
  detections,
  className,
  showLabels = true
}) => {
  // For a real implementation, we'd use TensorFlow.js here
  // For now, we'll just display the mock detections

  return (
    <div className={cn("relative w-full h-full", className)}>
      {detections.map((detection) => (
        <div
          key={detection.id}
          className="absolute border-2 border-primary rounded-md"
          style={{
            left: `${detection.bbox.x * 100}%`,
            top: `${detection.bbox.y * 100}%`,
            width: `${detection.bbox.width * 100}%`,
            height: `${detection.bbox.height * 100}%`,
          }}
        >
          {showLabels && (
            <div className="absolute -top-7 left-0 glass-card px-2 py-1 rounded-md text-xs font-medium flex items-center">
              <span className="mr-1">{detection.label}</span>
              <span className="text-primary font-bold">{Math.round(detection.confidence * 100)}%</span>
              {detection.distance && (
                <span className="ml-2 text-xs opacity-80">{detection.distance.toFixed(1)}m</span>
              )}
            </div>
          )}
        </div>
      ))}

      {detections.length === 0 && (
        <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 glass-card px-4 py-2 rounded-full text-sm font-medium flex items-center">
          <Info className="h-4 w-4 mr-2 text-primary" />
          <span>No objects detected</span>
        </div>
      )}
    </div>
  );
};

export default ObjectDetection;
